# JavaScript-Snake-Game
JavaScript Snake game sources 
http://zetcode.com/javascript/snake/


Available under 2-Clause BSD License https://opensource.org/licenses/BSD-2-Clause
